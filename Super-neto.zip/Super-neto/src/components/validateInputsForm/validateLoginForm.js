import { validateFullName } from "./validateFullName.js";

const validateLoginForm = (formData) => {
  const results = {
    isValid: true,
    error: "",
  };
 
  // TODO validar email y password

  return results;
};

export { validateLoginForm };