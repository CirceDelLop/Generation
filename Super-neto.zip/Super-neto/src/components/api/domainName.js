
const domainName =  ()=>{
    return "http://localhost:8080";
    //return "";
}


export {domainName}