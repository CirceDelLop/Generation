const spinnerWrapper = document.querySelector(".spinner-wrapper");

setTimeout(() => {
    spinnerWrapper.style.opacity = '0';

}, 3000);