import '/styles.scss'
import * as bootstrap from 'bootstrap'
import './about-us.css'
import { navbarApp } from '../../components/navbar/navbar-app.js'

document.querySelector("#navbar-app").innerHTML= navbarApp();

