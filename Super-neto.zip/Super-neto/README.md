<h1>Ejercicio Ch42 con vite<h1>

## Instrucciones de uso

### Instalar las librerías con npm

```bash
 npm install
```

### Usar Vite en modo desarroll

En la línea de comandos ejecuta

```bash
 npm run dev
```